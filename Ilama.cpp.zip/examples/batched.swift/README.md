This is a swift clone of `examples/batched`.

```bash
$ ./llama-batched-swift MODEL_PATH [PROMPT] [PARALLEL]
```
